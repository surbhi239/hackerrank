package com.hackerrank.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hackerrank.dao.LoginDAO;
import com.hackerrank.exceptions.HackerRankException;
import com.hackerrank.model.LoginDetails;


/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		
		String page = "HackerRank.jsp";
		PrintWriter out = response.getWriter();
		/*if(username.equals("") || password.equals(""))
		{
		out.print("Please enter username and password correctly");
		page = "HackerRank.jsp";
		}*/
		LoginDetails login = new LoginDetails(username,password);
		LoginDAO dao = new LoginDAO();
		boolean check = false;
		
		try {
		check = dao.loginCheck(login);
		if(check)
		{
			HttpSession session = request.getSession();
			session.setAttribute("user", login);
			
			System.out.println("Logged in" + username );
			
			page = "Success.jsp";
			
			
	 	}
		else
		{
			request.setAttribute("error", "Wrong Login and Password");
			System.out.println("Cannot Login" + "error page");
			page = "HackerRank.jsp";
			
		}
		
		}catch (HackerRankException e) {
			// TODO Auto-generated catch block
			request.setAttribute("error", "Some internal error contact to db admin");
		}
		RequestDispatcher rd =  request.getRequestDispatcher(page);
		rd.forward(request,response);
	}

}
