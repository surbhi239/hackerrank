package com.hackerrank.exceptions;

public class HackerRankException extends Exception {
	
	private String message;
	
	

	public HackerRankException(String message) {
		super(message);
		
	}



	@Override
	public String toString() {
		return "PayrollException [message=" + message + "]";
	}

}
