package com.hackerrank.controllers;

import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.context.annotation.SessionScope;
import org.springframework.web.servlet.ModelAndView;
import com.hackerrank.dao.HackerRankRegisterDao;
import com.hackerrank.dao.LoginDAO;
import com.hackerrank.exceptions.HackerRankException;
import com.hackerrank.model.HackerRankRegister;
import com.hackerrank.model.LoginDetails;

@ComponentScan({"com.hackerrank"})
@SessionAttributes("loginDetails")
@Controller

public class TestController {

		@GetMapping("/home")
		public String home(HttpServletRequest request){
			System.out.println("Home");
			
			System.out.println(request.getSession().getAttribute("loginDetails"));
			return "HackerRank";
			
		}
		
		@PostMapping("/LoginController")
		public ModelAndView login( LoginDetails loginDetails,LoginDAO loginDao){
			
			System.out.println(loginDetails);
			System.out.println(loginDao);
			
			String view="Success";
			ModelAndView mav=null;
			
			try {
			boolean ch=	loginDao.loginCheck(loginDetails);
			
			if(ch){
				 mav=new ModelAndView(view);
				
			}else{
				view="HackerRank";
				 mav=new ModelAndView(view);
				 mav.addObject("error", "username password is wrong");
			}
			
			} catch (HackerRankException e) {
				// TODO Auto-generated catch block
				view="HackerRank";
				 mav=new ModelAndView(view);
				mav.addObject("error", e.getMessage());
				 e.printStackTrace();
			}
			
			return mav;	
		}
		
		@GetMapping("/register")
		public String register(@ModelAttribute HackerRankRegister hackerrankregister){
			System.out.println(hackerrankregister);
			return "HackerRank";
		}
		
		@PostMapping("/reg")
		public String reg(HackerRankRegisterDao hackerrankregisterdao, HackerRankRegister hackerrankregister){
			System.out.println(hackerrankregisterdao);
			System.out.println(hackerrankregister);
			return "Success";
		}
}