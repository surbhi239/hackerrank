function validateForm() {
    var x = document.forms["myForm"]["username"].value;
    var y = document.forms["myForm"]["password"].value;
    if (x == "" || y == "") {
        alert("UserName or Password must be filled out");
        return false;
    }
}

function validateRegister() {
    var x = document.forms["registerform"]["user1"].value;
    var y = document.forms["registerform"]["pass1"].value;
    var z = document.forms["registerform"]["email"].value;
    var w = document.forms["registerform"]["conpass"].value;
    var regularExpression = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;
    if (x == "" || y == ""|| z == "") {
        alert("UserName or Password or email must be filled out");
        return false
    }
    
    else if(y!=w)
    {
    	 alert("Password and Confirm Password do not match");
    	 return false;
    }
    else if(regularExpression.test(y))
    {
    	
    	return true;
    }
    else
    {
    	alert("Match Password Requirements");
    	return false;
    }
}